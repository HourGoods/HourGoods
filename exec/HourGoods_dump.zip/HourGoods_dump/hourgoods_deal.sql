-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: k8a204.p.ssafy.io    Database: hourgoods
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `deal`
--

DROP TABLE IF EXISTS `deal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `deal_type` varchar(255) DEFAULT NULL,
  `image_url` varchar(150) DEFAULT NULL,
  `is_available` bit(1) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `meeting_location` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `concert_id` bigint DEFAULT NULL,
  `deal_host_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4bw4nven2tkfq07r4b7ip9be` (`concert_id`),
  KEY `FK5oikmyy18fv607q6krquq2wif` (`deal_host_id`),
  CONSTRAINT `FK4bw4nven2tkfq07r4b7ip9be` FOREIGN KEY (`concert_id`) REFERENCES `concert` (`id`),
  CONSTRAINT `FK5oikmyy18fv607q6krquq2wif` FOREIGN KEY (`deal_host_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deal`
--

LOCK TABLES `deal` WRITE;
/*!40000 ALTER TABLE `deal` DISABLE KEYS */;
INSERT INTO `deal` VALUES (4,'박정현 5집 팔아요!!\n네고는 안됩니다! 쿨거래 원해요..','Trade','image/deal/1684426074921%EC%A1%B0%ED%95%9C%ED%95%9C%29.jpg',_binary '',37.517910455309355,127.12672455033334,'핸드볼 경기장 GS25 편의점 앞','2023-05-20 13:00:00','5집 앨범 팔아요!!!',185,2),(5,'선착순으로 2시부터 신청하신 20분만 드립니다!\n줄서기는 금지되어 있어서 아래 버튼으로 신청하고 오셔서 번호 보여주세요~!','Sharing','image/deal/1684426501307%EC%A1%B0%ED%95%9C%ED%95%9C2.png',_binary '',37.52108752645286,127.12575425161172,'88호수 수변무대 오른쪽에서 기다릴게요!','2023-05-20 14:00:00','쿠키 나눔합니다. 20명 선착순~',185,2),(6,'박정현 1집 앨범입니다~\n외부 케이스 상태는 사진 봐주세요!\n내부 사진집이랑 cd 자체는 아주 깨끗합니다~\n낙찰받은 분 거래는 올림픽 공원역 CU 앞에서 해요~','Auction','image/deal/1684426957191%EC%A1%B0%ED%95%9C%ED%95%9Ca.jpg',_binary '',37.516532770029585,127.13008737675855,'올림픽 공원역 CU 앞','2023-05-20 12:30:00','박정현 1집 앨범 CD',185,2),(7,'박정현 노래 CD판매합니다.\n\n중고라서 물건에 큰 하자 없으면 교환, 환불은 어려운 점 이해 부탁드려요 : )','Trade','image/deal/1684427378906%EC%A1%B0%ED%95%9C%ED%95%9Cd.jpg',_binary '',37.517204928697446,127.1292571445969,'만남의 광장 가운데','2023-05-20 16:00:00','박정현 CD판매합니다.',185,2),(8,'픽쳐디스크라서 이쁩니다.','Auction','image/deal/1684428095269%EB%8F%99%EB%8F%990.jpg',_binary '',37.52111176070152,127.12835325656611,'매표소 앞','2023-05-20 14:00:00','박정현 미개봉 LP 판매합니다',185,3),(9,'사용감 조금 있어요,,','Trade','image/deal/1684428460759%EB%8F%99%EB%8F%990.jpg',_binary '',37.51654024580638,127.13147304235781,'올림픽공원역 1번 출구','2023-05-20 10:30:00','naturally 카세트테이프 팝니다.',185,3),(10,'표지가 없습니다.\n경매로 판매합니다.\n낙찰받으시면 대화 걸어주세요.','Auction','image/deal/1684428636192%EC%A1%B0%ED%95%9C%ED%95%9C%7D.jpg',_binary '',37.517362214218544,127.12112439368738,'야외조형전시장 골목 입구','2023-05-20 11:00:00','박정현 4집 CD 판매합니다.',185,2),(11,'정현이 누나 친필 싸인 들어간 라이브 앨범 팔아요~ 좋은 노래들만 들어 있어요~','Trade','image/deal/1684428757952%EA%B8%B8%ED%98%84d.png',_binary '',37.52111176070152,127.12835325656611,'8번 게이트 앞','2023-05-20 11:00:00','박정현 친필 싸인 앨범 팔아요!!',185,4),(12,'모두가 아는 그 노래! 꿈에!!가 수록되어 있는 4집 앨범 입니다 타이틀 곡 꿈에뿐만 아니라 12곡이 더 들어 있어요!\n','Trade','image/deal/1684429463419%EA%B8%B8%ED%98%84%EC%A7%91.png',_binary '',37.52111176070152,127.12835325656611,'1번 게이트 앞','2023-05-20 00:00:00','박정현 4집 앨범 팔아요~',185,4),(13,'1000장 한정으로 나온 박정현 LP 팝니다.\n미개봉 새 제품입니다.\n무료배송','Trade','image/deal/1684437551016%EA%B7%9C%ED%88%AC%EB%A6%AC6.jpg',_binary '',37.52111176070152,127.12835325656611,'올공 GS25 앞','2023-05-20 12:00:00','박정현 LP (1000장 한정판)',185,6),(14,'규연이 팬분들을 위해 특별히 5분께 규연이 화풍으로 손그림 그려드려요.','Sharing','image/deal/1684437836721%EA%B7%9C%ED%88%AC%EB%A6%AC4.PNG',_binary '',37.49649863404996,127.0320537561033,'강남역 12번 출구','2023-05-19 13:00:00','[재능기부] 손그림 그려드립니다',232,6),(15,'착용감 조금 있습니다 참고해주세요! 저는 좌석이라 네시에 거래 가능한데 세시로도 조정 가능합니다 챗 주세요!','Trade','image/deal/1684452386534%EB%8B%A4%EC%86%9C.jpeg',_binary '',37.49649863404996,127.0320537561033,'협의 가능','2023-05-19 16:00:00','다솜 손민수템! 다솜가방 팔아요',232,5),(16,'시세 모르고 문의하는 분이 너무 많네요. 그냥 경매 붙입니다. 낙찰되신 분은 메세지 주시면 됩니다. 올림픽 수영장 2번 게이트 근처에서 진행할거고, 거래 시간은 스탠딩 입장 전으로 원합니다.','Auction','image/deal/1684459601620%EB%8B%A4%EC%86%9CB.jpg',_binary '',37.520383581593215,127.12684185313843,'올림픽수영장','2023-05-19 10:00:00','주연 리빌 포토카드 경매 받습니다',125,5),(17,'20만원입니다. 네고 불가합니다. 포인트 거래로 진행하니 포인트 없으신 분은 사절입니다. 강남역 근처에서 만날 수 있습니다.','Trade','image/deal/1684459727530%EB%8B%A4%EC%86%9CA.jpg',_binary '',37.49790504149288,127.02880312157068,'강남역','2023-05-19 15:00:00','다솜 생일 한정 포토카드 A버전 팝니다',232,5),(18,'젠틀몬스터 선글라스 끼고 있는 규연이 포토카드 24000원부터 시작해요. 이번 김규연과 아이들 월드투어 포스터 사진입니다. 많은 관심 부탁드려요.','Auction','image/deal/1684459754693%EA%B7%9C%ED%88%AC%EB%A6%AC.jpeg',_binary '\0',37.49649863404996,127.0320537561033,'뱅뱅사거리 앞','2023-05-19 11:00:00','[경매] 젠틀몬스터 규투리 포토카드 경매합니다',232,6),(19,'사용감 있고, 사이즈 m입니다! 160cm 여자 기준 딱 예쁜 오버핏이에요. 사용감이 조금 있어 나눔 진행합니다. 나눔은 2시 30분 성공하시면 바로 40분까지 푸른솔 도서관 오실 수 있는 분만 신청해주세요 ㅎㅎ','Sharing','image/deal/1684459892084%EB%8B%A4%EC%86%9C6.jpg',_binary '',37.49649863404996,127.0320537561033,'푸른솔도서관','2023-05-19 14:30:00','동현 손민수 맨투맨 나눔합니다',232,5),(20,'사용감 조금 있어요','Trade','image/deal/1684460016321%EB%8F%99%EB%8F%99.jpeg',_binary '',37.49649863404996,127.0320537561033,'8층 휴게실','2023-05-19 18:00:00','규연이 옆자리에서 주운 키보드 팔아요',232,3),(21,'다솜이가 사용하던 예쁜 삼성 노트북 경매합니다. 낙찰하신 분은 오늘 공연 끝나고 바로 거래 가능합니다! ','Auction','image/deal/1684460367930%EB%8B%A4%EC%86%9C7.jpg',_binary '',37.496679884514585,127.02792059105627,'강남역 6번 출구','2023-05-19 12:00:00','다솜이의 삼성 노트북',232,5),(22,'사용감이 있고 무거운걸 돌릴 때 비행기 이륙 소리가 나지만 아직 사용하기엔 문제 없습니다~','Trade','image/deal/1684461030807%EA%B8%B8%ED%98%84%EB%B6%81.jpg',_binary '\0',37.49649863404996,127.0320537561033,'역삼푸른솔도서관 정문','2023-05-19 10:00:00','싸피 노트북 팔아요~',232,4),(23,'어렵게 구했습니다','Trade','image/deal/1684461618738%EB%8B%A4%EC%86%9C0.png',_binary '',37.52111176070152,127.12835325656611,'올림픽공원','2023-05-19 20:00:00','백예린 LP 팝니다',189,5),(24,'일괄 처분이 목적입니다','Trade','image/deal/1684461713505%EB%8B%A4%EC%86%9CQ.jpg',_binary '',37.55816736465536,127.00671708300007,'장충','2023-05-20 18:00:00','조우즈 포카 모두 판매',202,5),(25,'임영웅 포카 개당 2000원에 판매하고 있어요~','Trade','image/deal/1684461745018%EA%B8%B8%ED%98%84%EC%B9%B4.png',_binary '',37.66930063041245,126.74568006831795,'킨텍스 제1전시장 1번 게이트 앞','2023-05-20 12:00:00','임영웅 포카 팔아요~',216,4),(26,'그래서 제가 노래해드림 ㅋㅋ','Sharing','image/deal/1684461773357%EB%8B%A4%EC%86%9Cd.png',_binary '',37.54568442939672,127.10795894391912,'ㅋㅋㅋ','2023-05-27 18:00:00','에비씩스 노래 좋은 거 많음',81,5),(27,'아직 미지근 합니다,,,','Trade','image/deal/1684462492878%EB%8F%99%EB%8F%99.jpeg',_binary '\0',37.494814613731975,127.0287001610595,'강남역 바나프레소','2023-05-19 12:00:00','반쯤 남은 캐모마일 팔아요',232,3),(28,'포토카드 팝니다. \n쿨거래 원해요~','Trade','image/deal/1684462932649%EC%A1%B0%ED%95%9C%ED%95%9CA.jpg',_binary '\0',37.49566146325125,127.02909627589182,'4번 출구 앞','2023-05-19 13:00:00','포토카드 판매합니다.',232,2),(29,'규투리한테 허락맡고 따라 산 거에여','Trade','image/deal/1684463068003%EB%8F%99%EB%8F%99.jpeg',_binary '\0',37.49649863404996,127.0320537561033,'1층 안내데스크 앞','2023-05-19 10:00:00','규투리 노트북파우치 똑같은거 팔아여',232,3),(30,'배고파서 많이 시켯는데 좀 남앗어용,,','Sharing','image/deal/1684463374735%EB%8F%99%EB%8F%99.jpeg',_binary '',37.49649863404996,127.0320537561033,'멀티캠퍼스 앞','2023-05-19 11:30:00','마카롱 나눔해여',232,3),(31,'어렵게 구한 김규연과 아이들 포토카드 경매합니다. 거래는 역삼 푸른솔 도서관 앞에서 해요. 많은 관심 부탁드립니다.','Auction','image/deal/1684463638625%EA%B7%9C%ED%88%AC%EB%A6%AC3.JPG',_binary '',37.49649863404996,127.0320537561033,'역삼 푸른솔 도서관','2023-05-19 11:00:00','[경매] 희귀 규투리 포카 경매합니다',232,6);
/*!40000 ALTER TABLE `deal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-19 11:38:23
